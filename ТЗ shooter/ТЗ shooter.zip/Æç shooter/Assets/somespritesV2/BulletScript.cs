using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour
{
    private GunScript _gunScript;
    private Rigidbody _rigidbody;
    [SerializeField] private float _speed;
    private Camera cmCam;
    [SerializeField] private GameObject _player;

    private Rigidbody rb;
    private void Awake()
    {
        _rigidbody = new Rigidbody();
        cmCam = GetComponent<Camera>();
        rb = gameObject.GetComponent<Rigidbody>();

    }

    private void Start()
    {
        BulletFly();
    }

    private void Update()
    {
       // var gopos = gameObject.transform.position;
      //  gameObject.transform.rotation = cmCam.transform.rotation;
       // gameObject.transform.position = new Vector3(1,1,3) * _speed * Time.deltaTime;
        _rigidbody.MovePosition(transform.position + new Vector3(0f,0f,3f) *Time.deltaTime * _speed);


    }

    public void BulletFly()
    {
        var position = _rigidbody.position;
       // position = gameObject.transform.position;
       
        _rigidbody.MovePosition(position + new Vector3(0f,0f,3f) *Time.deltaTime * _speed);
        //_rigidbody.AddForce(position * _speed, ForceMode.Impulse);
    }
    
}
