using UnityEngine;

namespace somespritesV2
{
    public class SpawnComponent : MonoBehaviour
    {
        [SerializeField] private Transform _target;
        [SerializeField] private GameObject _prefab;
        private bool d = false;
        [ContextMenu("Spawn")]
        public void Spawn()
        {
            var instantiate = Instantiate(_prefab, _target.position,Quaternion.identity);
            var scale = new Vector3(0.3f,0.3f,0.3f);
            instantiate.transform.localScale = scale;
            instantiate.SetActive(true);
        }
    }
}

 