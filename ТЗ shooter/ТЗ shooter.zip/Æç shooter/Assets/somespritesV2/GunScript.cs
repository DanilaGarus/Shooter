
using System;
using Cinemachine;
using somespritesV2;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

public class GunScript : MonoBehaviour
{
    [SerializeField] private float _damage;
    [SerializeField] private float range = 100f;
   // [SerializeField] private Cooldown _cooldown;
   
    public Camera cmCam;
    private Vector3 startingRotation;
    private InputManager im;
    private PlayerControls playerControls;
    private InputManager inputManager;
    [SerializeField]  private Cooldown _cooldown;
    [SerializeField] private GameObject _gun;
    [SerializeField] private GameObject _player;
    [SerializeField] private UnityEvent _action;

    private void Awake()
    {
        _gun = GetComponent<GameObject>();
        _player = GetComponent<GameObject>();
    }

    private void Start()
    {
        inputManager = InputManager.Instance;
    }

    private void Update()
    {
        if (inputManager.PlayerShooted() && _cooldown.IsReady)
        {
            Shoot();
        }
        
        _gun.transform.rotation = cmCam.transform.rotation;
        _gun.transform.position = _player.transform.position;
    }

   

    public void Shoot()
    { 
        RaycastHit hit; 
        if (Physics.Raycast(cmCam.transform.position, cmCam.transform.forward, out hit, range)) 
        { 
            Debug.Log(hit.transform.name);
        }
        Target target = hit.transform.GetComponent<Target>(); 
        if (target != null) 
        { 
            target.TakeDamage(_damage); 
            Debug.Log(target.health);
        } 
        _cooldown.Reset();
        _action.Invoke();
    }

   


}
